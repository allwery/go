package com.example.myapplication2

class User(val login: String, val email: String, val pass: String) {
}