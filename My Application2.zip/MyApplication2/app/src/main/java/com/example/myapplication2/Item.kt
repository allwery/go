package com.example.myapplication2

class Item(val id: Int, val image: String, val title: String, val description: String, val text: String, val price: Int) {

}